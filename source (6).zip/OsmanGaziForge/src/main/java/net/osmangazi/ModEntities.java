package net.osmangazi;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, OsmanGaziMod.MODID);
    private static final Map<String, RegistryObject<EntityType<OsmanUnit>>> TYPES = new HashMap<>();
    private static final Map<String, RegistryObject<EntityType<OsmanHorse>>> HORSES = new HashMap<>();

    public static final RegistryObject<EntityType<CannonballEntity>> CANNONBALL = ENTITIES.register("gulle", () ->
        EntityType.Builder.<CannonballEntity>of(CannonballEntity::new, MobCategory.MISC)
            .sized(0.4F, 0.4F).clientTrackingRange(4).updateInterval(10).build(ENTITIES.key("gulle")));

    static {
        for (UnitDef def : UnitDef.ALL) {
            TYPES.put(def.id(), ENTITIES.register(def.id(), () ->
                EntityType.Builder.<OsmanUnit>of((type, level) -> new OsmanUnit(type, level, def), MobCategory.CREATURE)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build(ENTITIES.key(def.id()))));
        }
        for (OsmanHorse.HorseDef hd : OsmanHorse.ALL) {
            HORSES.put(hd.id(), ENTITIES.register(hd.id(), () ->
                EntityType.Builder.<OsmanHorse>of((type, level) -> new OsmanHorse(type, level, hd), MobCategory.CREATURE)
                    .sized(1.3964844F, 1.6F).clientTrackingRange(10).build(ENTITIES.key(hd.id()))));
        }
    }

    public static EntityType<OsmanHorse> horseType(UnitDef.Faction f) {
        for (OsmanHorse.HorseDef hd : OsmanHorse.ALL) if (hd.faction() == f) return HORSES.get(hd.id()).get();
        throw new IllegalArgumentException("at yok: " + f);
    }

    public static RegistryObject<EntityType<OsmanHorse>> horseObject(String id) { return HORSES.get(id); }
    public static EntityType<OsmanUnit> type(String id) { return TYPES.get(id).get(); }
    public static RegistryObject<EntityType<OsmanUnit>> object(String id) { return TYPES.get(id); }

    public static void attributes(EntityAttributeCreationEvent e) {
        for (UnitDef def : UnitDef.ALL) e.put(type(def.id()), OsmanUnit.createAttributes(def).build());
        for (OsmanHorse.HorseDef hd : OsmanHorse.ALL) e.put(HORSES.get(hd.id()).get(), OsmanHorse.createAttributes().build());
    }

    public static void spawnPlacements(SpawnPlacementRegisterEvent e) {
        for (UnitDef def : UnitDef.ALL)
            e.register(type(def.id()), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Mob::checkMobSpawnRules, SpawnPlacementRegisterEvent.Operation.OR);
        for (OsmanHorse.HorseDef hd : OsmanHorse.ALL)
            e.register(HORSES.get(hd.id()).get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Mob::checkMobSpawnRules, SpawnPlacementRegisterEvent.Operation.OR);
    }
}
